import { createPool, type Pool } from "mysql2/promise"

let pool: Pool | null = null

export async function getConnection() {
  if (!pool) {
    pool = createPool({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      connectionLimit: 10,
    })
  }
  return pool
}

export async function query(sql: string, params: any[] = []) {
  const connection = await getConnection()
  const [results] = await connection.execute(sql, params)
  return results
}

