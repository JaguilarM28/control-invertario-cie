import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

const recentAssignments = [
  {
    employee: "Alice Johnson",
    equipment: "Laptop Dell XPS",
    date: "2023-06-15",
  },
  {
    employee: "Bob Smith",
    equipment: "Monitor LG 27\"",
    date: "2023-06-14",
  },
  {
    employee: "Charlie Brown",
    equipment: "Teclado Logitech",
    date: "2023-06-13",
  },
  {
    employee: "Diana Ross",
    equipment: "Mouse Microsoft",
    date: "2023-06-12",
  },
  {
    employee: "Edward Norton",
    equipment: "Docking Station HP",
    date: "2023-06-11",
  },
]

export function RecentAssignments() {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Empleado</TableHead>
          <TableHead>Equipo</TableHead>
          <TableHead>Fecha</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {recentAssignments.map((assignment) => (
          <TableRow key={assignment.employee}>
            <TableCell className="font-medium">{assignment.employee}</TableCell>
            <TableCell>{assignment.equipment}</TableCell>
            <TableCell>{assignment.date}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}

