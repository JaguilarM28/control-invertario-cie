import { useState } from "react"
import { Pencil, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { EmpleadoDialog } from "@/components/empleado-dialog"

export function EmpleadoTable({ empleados, onEdit, onDelete }) {
  const [editingEmpleado, setEditingEmpleado] = useState(null)

  return (
    <>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[100px]">Número</TableHead>
              <TableHead>Nombre</TableHead>
              <TableHead className="hidden md:table-cell">Cargo</TableHead>
              <TableHead className="hidden lg:table-cell">Departamento</TableHead>
              <TableHead className="hidden xl:table-cell">Estado</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {empleados.map((empleado) => (
              <TableRow key={empleado.id}>
                <TableCell className="font-medium">{empleado.numeroEmpleado}</TableCell>
                <TableCell>{`${empleado.nombres} ${empleado.apellidos}`}</TableCell>
                <TableCell className="hidden md:table-cell">{empleado.nombreCargo}</TableCell>
                <TableCell className="hidden lg:table-cell">{empleado.departamento}</TableCell>
                <TableCell className="hidden xl:table-cell">{empleado.estado}</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" onClick={() => setEditingEmpleado(empleado)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => onDelete(empleado.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      {editingEmpleado && (
        <EmpleadoDialog
          isOpen={true}
          onClose={() => setEditingEmpleado(null)}
          onSave={(updatedEmpleado) => {
            onEdit(updatedEmpleado)
            setEditingEmpleado(null)
          }}
          empleado={editingEmpleado}
        />
      )}
    </>
  )
}

