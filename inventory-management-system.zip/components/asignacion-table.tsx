import { useState } from "react"
import { Pencil, Trash2 } from 'lucide-react'
import { Button } from "@/components/ui/button"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { AsignacionDialog } from "@/components/asignacion-dialog"

export function AsignacionTable({ asignaciones, onEdit, onDelete }) {
  const [editingAsignacion, setEditingAsignacion] = useState(null)

  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Empleado</TableHead>
            <TableHead>Equipo</TableHead>
            <TableHead>Fecha de Asignación</TableHead>
            <TableHead>Fecha de Devolución</TableHead>
            <TableHead>Acciones</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {asignaciones.map((asignacion) => (
            <TableRow key={asignacion.id}>
              <TableCell>{asignacion.empleado}</TableCell>
              <TableCell>{asignacion.equipo}</TableCell>
              <TableCell>{asignacion.fechaAsignacion}</TableCell>
              <TableCell>{asignacion.fechaDevolucion || 'N/A'}</TableCell>
              <TableCell>
                <Button variant="ghost" size="icon" onClick={() => setEditingAsignacion(asignacion)}>
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => onDelete(asignacion.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {editingAsignacion && (
        <AsignacionDialog
          isOpen={true}
          onClose={() => setEditingAsignacion(null)}
          onSave={(updatedAsignacion) => {
            onEdit(updatedAsignacion)
            setEditingAsignacion(null)
          }}
          asignacion={editingAsignacion}
        />
      )}
    </>
  )
}

