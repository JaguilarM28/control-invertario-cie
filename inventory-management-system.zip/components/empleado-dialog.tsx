import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function EmpleadoDialog({ isOpen, onClose, onSave, empleado = null }) {
  const [formData, setFormData] = useState({
    numeroEmpleado: "",
    nombres: "",
    apellidos: "",
    nombreCargo: "",
    empresa: "",
    departamento: "",
    nomJefe: "",
    puestoJefe: "",
    estado: "Activo",
  })

  useEffect(() => {
    if (empleado) {
      setFormData(empleado)
    } else {
      setFormData({
        numeroEmpleado: "",
        nombres: "",
        apellidos: "",
        nombreCargo: "",
        empresa: "",
        departamento: "",
        nomJefe: "",
        puestoJefe: "",
        estado: "Activo",
      })
    }
  }, [empleado])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSave = () => {
    onSave(formData)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{empleado ? "Editar Empleado" : "Agregar Empleado"}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="numeroEmpleado" className="text-right">
              Número
            </Label>
            <Input
              id="numeroEmpleado"
              name="numeroEmpleado"
              value={formData.numeroEmpleado}
              onChange={handleChange}
              className="col-span-3"
              placeholder="Ej. EMP001"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="nombres" className="text-right">
              Nombres
            </Label>
            <Input
              id="nombres"
              name="nombres"
              value={formData.nombres}
              onChange={handleChange}
              className="col-span-3"
              placeholder="Ej. Juan Carlos"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="apellidos" className="text-right">
              Apellidos
            </Label>
            <Input
              id="apellidos"
              name="apellidos"
              value={formData.apellidos}
              onChange={handleChange}
              className="col-span-3"
              placeholder="Ej. Pérez García"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="nombreCargo" className="text-right">
              Cargo
            </Label>
            <Input
              id="nombreCargo"
              name="nombreCargo"
              value={formData.nombreCargo}
              onChange={handleChange}
              className="col-span-3"
              placeholder="Ej. Desarrollador Senior"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="empresa" className="text-right">
              Empresa
            </Label>
            <Input
              id="empresa"
              name="empresa"
              value={formData.empresa}
              onChange={handleChange}
              className="col-span-3"
              placeholder="Ej. TechCorp"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="departamento" className="text-right">
              Departamento
            </Label>
            <Input
              id="departamento"
              name="departamento"
              value={formData.departamento}
              onChange={handleChange}
              className="col-span-3"
              placeholder="Ej. Desarrollo"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="nomJefe" className="text-right">
              Jefe
            </Label>
            <Input
              id="nomJefe"
              name="nomJefe"
              value={formData.nomJefe}
              onChange={handleChange}
              className="col-span-3"
              placeholder="Ej. María González"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="puestoJefe" className="text-right">
              Puesto Jefe
            </Label>
            <Input
              id="puestoJefe"
              name="puestoJefe"
              value={formData.puestoJefe}
              onChange={handleChange}
              className="col-span-3"
              placeholder="Ej. Gerente de Desarrollo"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="estado" className="text-right">
              Estado
            </Label>
            <Select
              onValueChange={(value) => setFormData((prev) => ({ ...prev, estado: value }))}
              defaultValue={formData.estado}
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Seleccionar estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Activo">Activo</SelectItem>
                <SelectItem value="Baja">Baja</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" onClick={handleSave}>
            Guardar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

