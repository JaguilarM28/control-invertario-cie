import { useState } from "react"
import { Pencil, Trash2 } from 'lucide-react'
import { Button } from "@/components/ui/button"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { EquipoDialog } from "@/components/equipo-dialog"

export function EquipoTable({ equipos, onEdit, onDelete }) {
  const [editingEquipo, setEditingEquipo] = useState(null)

  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nombre</TableHead>
            <TableHead>Modelo</TableHead>
            <TableHead>Serial</TableHead>
            <TableHead>Estado</TableHead>
            <TableHead>Acciones</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {equipos.map((equipo) => (
            <TableRow key={equipo.id}>
              <TableCell>{equipo.nombre}</TableCell>
              <TableCell>{equipo.modelo}</TableCell>
              <TableCell>{equipo.serial}</TableCell>
              <TableCell>{equipo.estado}</TableCell>
              <TableCell>
                <Button variant="ghost" size="icon" onClick={() => setEditingEquipo(equipo)}>
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => onDelete(equipo.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {editingEquipo && (
        <EquipoDialog
          isOpen={true}
          onClose={() => setEditingEquipo(null)}
          onSave={(updatedEquipo) => {
            onEdit(updatedEquipo)
            setEditingEquipo(null)
          }}
          equipo={editingEquipo}
        />
      )}
    </>
  )
}

