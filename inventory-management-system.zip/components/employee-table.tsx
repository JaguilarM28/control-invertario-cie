import { useState } from "react"
import { Pencil, Trash2 } from 'lucide-react'
import { Button } from "@/components/ui/button"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { EmployeeDialog } from "@/components/employee-dialog"

export function EmployeeTable({ employees, onEdit, onDelete }) {
  const [editingEmployee, setEditingEmployee] = useState(null)

  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nombre</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Departamento</TableHead>
            <TableHead>Acciones</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {employees.map((employee) => (
            <TableRow key={employee.id}>
              <TableCell>{employee.name}</TableCell>
              <TableCell>{employee.email}</TableCell>
              <TableCell>{employee.department}</TableCell>
              <TableCell>
                <Button variant="ghost" size="icon" onClick={() => setEditingEmployee(employee)}>
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => onDelete(employee.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {editingEmployee && (
        <EmployeeDialog
          isOpen={true}
          onClose={() => setEditingEmployee(null)}
          onSave={(updatedEmployee) => {
            onEdit(updatedEmployee)
            setEditingEmployee(null)
          }}
          employee={editingEmployee}
        />
      )}
    </>
  )
}

