import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export function AsignacionDialog({ isOpen, onClose, onSave, asignacion = null }) {
  const [empleado, setEmpleado] = useState("")
  const [equipo, setEquipo] = useState("")
  const [fechaAsignacion, setFechaAsignacion] = useState("")
  const [fechaDevolucion, setFechaDevolucion] = useState("")

  useEffect(() => {
    if (asignacion) {
      setEmpleado(asignacion.empleado)
      setEquipo(asignacion.equipo)
      setFechaAsignacion(asignacion.fechaAsignacion)
      setFechaDevolucion(asignacion.fechaDevolucion || "")
    } else {
      setEmpleado("")
      setEquipo("")
      setFechaAsignacion("")
      setFechaDevolucion("")
    }
  }, [asignacion])

  const handleSave = () => {
    onSave({ id: asignacion?.id, empleado, equipo, fechaAsignacion, fechaDevolucion: fechaDevolucion || null })
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{asignacion ? "Editar Asignación" : "Nueva Asignación"}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="empleado" className="text-right">
              Empleado
            </Label>
            <Input
              id="empleado"
              value={empleado}
              onChange={(e) => setEmpleado(e.target.value)}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="equipo" className="text-right">
              Equipo
            </Label>
            <Input
              id="equipo"
              value={equipo}
              onChange={(e) => setEquipo(e.target.value)}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="fechaAsignacion" className="text-right">
              Fecha de Asignación
            </Label>
            <Input
              id="fechaAsignacion"
              type="date"
              value={fechaAsignacion}
              onChange={(e) => setFechaAsignacion(e.target.value)}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="fechaDevolucion" className="text-right">
              Fecha de Devolución
            </Label>
            <Input
              id="fechaDevolucion"
              type="date"
              value={fechaDevolucion}
              onChange={(e) => setFechaDevolucion(e.target.value)}
              className="col-span-3"
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" onClick={handleSave}>Guardar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

