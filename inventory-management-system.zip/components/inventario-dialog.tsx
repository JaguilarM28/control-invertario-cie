import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"

export function InventarioDialog({ isOpen, onClose, onSave, item = null }) {
  const [formData, setFormData] = useState({
    numeroInventarioCIE: "",
    numeroSerie: "",
    nombreArticulo: "",
    categoria: "",
    marca: "",
    modelo: "",
    cantidad: 1,
    estadoArticulo: "Disponible",
    descripcion: "",
    ubicacion: "",
    esPropio: true,
  })

  useEffect(() => {
    if (item) {
      setFormData(item)
    } else {
      setFormData({
        numeroInventarioCIE: "",
        numeroSerie: "",
        nombreArticulo: "",
        categoria: "",
        marca: "",
        modelo: "",
        cantidad: 1,
        estadoArticulo: "Disponible",
        descripcion: "",
        ubicacion: "",
        esPropio: true,
      })
    }
  }, [item])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSave = () => {
    onSave(formData)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{item ? "Editar Artículo" : "Agregar Artículo"}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="numeroInventarioCIE" className="text-right">
              Número de Inventario
            </Label>
            <Input
              id="numeroInventarioCIE"
              name="numeroInventarioCIE"
              value={formData.numeroInventarioCIE}
              onChange={handleChange}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="numeroSerie" className="text-right">
              Número de Serie
            </Label>
            <Input
              id="numeroSerie"
              name="numeroSerie"
              value={formData.numeroSerie}
              onChange={handleChange}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="nombreArticulo" className="text-right">
              Nombre del Artículo
            </Label>
            <Input
              id="nombreArticulo"
              name="nombreArticulo"
              value={formData.nombreArticulo}
              onChange={handleChange}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="categoria" className="text-right">
              Categoría
            </Label>
            <Select
              onValueChange={(value) => setFormData((prev) => ({ ...prev, categoria: value }))}
              defaultValue={formData.categoria}
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Seleccionar categoría" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Monitor">Monitor</SelectItem>
                <SelectItem value="Docking">Docking</SelectItem>
                <SelectItem value="Kit de Mouse y Teclado">Kit de Mouse y Teclado</SelectItem>
                <SelectItem value="Laptop">Laptop</SelectItem>
                <SelectItem value="Macbook">Macbook</SelectItem>
                <SelectItem value="iMac">iMac</SelectItem>
                <SelectItem value="iPad">iPad</SelectItem>
                <SelectItem value="Desktop">Desktop</SelectItem>
                <SelectItem value="Candado">Candado</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="marca" className="text-right">
              Marca
            </Label>
            <Input id="marca" name="marca" value={formData.marca} onChange={handleChange} className="col-span-3" />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="modelo" className="text-right">
              Modelo
            </Label>
            <Input id="modelo" name="modelo" value={formData.modelo} onChange={handleChange} className="col-span-3" />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="cantidad" className="text-right">
              Cantidad
            </Label>
            <Input
              id="cantidad"
              name="cantidad"
              type="number"
              value={formData.cantidad}
              onChange={handleChange}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="estadoArticulo" className="text-right">
              Estado del Artículo
            </Label>
            <Select
              onValueChange={(value) => setFormData((prev) => ({ ...prev, estadoArticulo: value }))}
              defaultValue={formData.estadoArticulo}
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Seleccionar estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Disponible">Disponible</SelectItem>
                <SelectItem value="Asignado">Asignado</SelectItem>
                <SelectItem value="En Reparación">En Reparación</SelectItem>
                <SelectItem value="Fuera de Uso">Fuera de Uso</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="descripcion" className="text-right">
              Descripción
            </Label>
            <Textarea
              id="descripcion"
              name="descripcion"
              value={formData.descripcion}
              onChange={handleChange}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="ubicacion" className="text-right">
              Ubicación
            </Label>
            <Input
              id="ubicacion"
              name="ubicacion"
              value={formData.ubicacion}
              onChange={handleChange}
              className="col-span-3"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Switch
              id="esPropio"
              checked={formData.esPropio}
              onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, esPropio: checked }))}
            />
            <Label htmlFor="esPropio">Es propio</Label>
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" onClick={handleSave}>
            Guardar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

