"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  LayoutDashboard,
  Users,
  Monitor,
  ClipboardList,
  PenToolIcon as Tool,
  ShieldCheck,
  Truck,
  FileBarChart,
  Menu,
} from "lucide-react"

const sidebarItems = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Empleados", href: "/empleados", icon: Users },
  { name: "Equipos", href: "/equipos", icon: Monitor },
  { name: "Asignaciones", href: "/asignaciones", icon: ClipboardList },
  { name: "Mantenimiento", href: "/mantenimiento", icon: Tool },
  { name: "Garantías", href: "/garantias", icon: ShieldCheck },
  { name: "Proveedores", href: "/proveedores", icon: Truck },
  { name: "Reportes", href: "/reportes", icon: FileBarChart },
]

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false)
  const pathname = usePathname()

  return (
    <aside
      className={cn("bg-youtube-red text-white transition-all duration-300 ease-in-out", collapsed ? "w-16" : "w-64")}
    >
      <div className="flex h-full flex-col">
        <div className="flex items-center justify-between p-4">
          {!collapsed && <h2 className="text-lg font-semibold">Inventario</h2>}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCollapsed(!collapsed)}
            className="h-8 w-8 text-white hover:bg-red-700"
          >
            <Menu className="h-4 w-4" />
            <span className="sr-only">Toggle Sidebar</span>
          </Button>
        </div>
        <ScrollArea className="flex-1">
          <nav className="flex flex-col gap-2 p-2">
            {sidebarItems.map((item) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center rounded-lg px-3 py-2 text-sm font-medium transition-colors hover:bg-red-700",
                    pathname === item.href ? "bg-red-700" : "transparent",
                    collapsed ? "justify-center" : "justify-start",
                  )}
                >
                  <Icon className={cn("h-5 w-5", collapsed ? "mr-0" : "mr-3")} />
                  {!collapsed && <span>{item.name}</span>}
                </Link>
              )
            })}
          </nav>
        </ScrollArea>
      </div>
    </aside>
  )
}

