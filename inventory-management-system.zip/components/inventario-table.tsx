import { useState } from "react"
import { Pencil, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { InventarioDialog } from "@/components/inventario-dialog"

export function InventarioTable({ inventario, onEdit, onDelete }) {
  const [editingItem, setEditingItem] = useState(null)

  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Número de Inventario</TableHead>
            <TableHead>Número de Serie</TableHead>
            <TableHead>Artículo</TableHead>
            <TableHead>Categoría</TableHead>
            <TableHead>Estado</TableHead>
            <TableHead>Ubicación</TableHead>
            <TableHead>Acciones</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {inventario.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.numeroInventarioCIE}</TableCell>
              <TableCell>{item.numeroSerie}</TableCell>
              <TableCell>{item.nombreArticulo}</TableCell>
              <TableCell>{item.categoria}</TableCell>
              <TableCell>{item.estadoArticulo}</TableCell>
              <TableCell>{item.ubicacion}</TableCell>
              <TableCell>
                <Button variant="ghost" size="icon" onClick={() => setEditingItem(item)}>
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => onDelete(item.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {editingItem && (
        <InventarioDialog
          isOpen={true}
          onClose={() => setEditingItem(null)}
          onSave={(updatedItem) => {
            onEdit(updatedItem)
            setEditingItem(null)
          }}
          item={editingItem}
        />
      )}
    </>
  )
}

