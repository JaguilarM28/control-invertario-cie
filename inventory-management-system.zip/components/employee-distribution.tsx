"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const data = [
  { name: "IT", empleados: 65 },
  { name: "Ventas", empleados: 45 },
  { name: "Marketing", empleados: 30 },
  { name: "RH", empleados: 20 },
  { name: "Finanzas", empleados: 25 },
]

export function EmployeeDistribution() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Bar dataKey="empleados" fill="#8884d8" />
      </BarChart>
    </ResponsiveContainer>
  )
}

