"use client"

import { useState } from "react"
import { Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { InventarioTable } from "@/components/inventario-table"
import { InventarioDialog } from "@/components/inventario-dialog"

export default function InventarioPage() {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [inventario, setInventario] = useState([
    {
      id: 1,
      numeroInventarioCIE: "INV001",
      numeroSerie: "SER001",
      nombreArticulo: "Laptop Dell XPS",
      categoria: "Laptop",
      marca: "Dell",
      modelo: "XPS 15",
      cantidad: 1,
      estadoArticulo: "Disponible",
      descripcion: "Laptop de alto rendimiento",
      ubicacion: "Oficina principal",
      esPropio: true,
    },
    // Add more inventory items here
  ])

  const addInventario = (item) => {
    setInventario([...inventario, { ...item, id: inventario.length + 1 }])
  }

  const updateInventario = (updatedItem) => {
    setInventario(inventario.map((item) => (item.id === updatedItem.id ? updatedItem : item)))
  }

  const deleteInventario = (id) => {
    setInventario(inventario.filter((item) => item.id !== id))
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Inventario</h1>
        <Button onClick={() => setIsDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" /> Agregar Artículo
        </Button>
      </div>
      <InventarioTable inventario={inventario} onEdit={updateInventario} onDelete={deleteInventario} />
      <InventarioDialog isOpen={isDialogOpen} onClose={() => setIsDialogOpen(false)} onSave={addInventario} />
    </div>
  )
}

