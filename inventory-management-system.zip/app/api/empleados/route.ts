import { NextResponse } from "next/server"
import { query } from "@/lib/db"

export async function GET(request: Request) {
  try {
    const empleados = await query("SELECT * FROM Empleado")
    return NextResponse.json(empleados)
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const result = await query(
      "INSERT INTO Empleado (numeroEmpleado, nombres, apellidos, nombreCargo, empresa, departamento, nomJefe, puestoJefe, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
      [
        body.numeroEmpleado,
        body.nombres,
        body.apellidos,
        body.nombreCargo,
        body.empresa,
        body.departamento,
        body.nomJefe,
        body.puestoJefe,
        body.estado,
      ],
    )
    return NextResponse.json({ id: result.insertId }, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 })
  }
}

