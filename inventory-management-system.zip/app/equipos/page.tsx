"use client"

import { useState } from "react"
import { Plus } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { EquipoTable } from "@/components/equipo-table"
import { EquipoDialog } from "@/components/equipo-dialog"

export default function EquiposPage() {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [equipos, setEquipos] = useState([
    { id: 1, nombre: "Laptop Dell XPS", modelo: "XPS 15", serial: "DL001", estado: "Asignado" },
    { id: 2, nombre: "Monitor LG", modelo: "27UL500-W", serial: "LG001", estado: "Disponible" },
    { id: 3, nombre: "Teclado Logitech", modelo: "K780", serial: "LT001", estado: "En mantenimiento" },
  ])

  const addEquipo = (equipo) => {
    setEquipos([...equipos, { ...equipo, id: equipos.length + 1 }])
  }

  const updateEquipo = (updatedEquipo) => {
    setEquipos(equipos.map(eq => eq.id === updatedEquipo.id ? updatedEquipo : eq))
  }

  const deleteEquipo = (id) => {
    setEquipos(equipos.filter(eq => eq.id !== id))
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Equipos</h1>
        <Button onClick={() => setIsDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" /> Agregar Equipo
        </Button>
      </div>
      <EquipoTable 
        equipos={equipos} 
        onEdit={updateEquipo} 
        onDelete={deleteEquipo} 
      />
      <EquipoDialog 
        isOpen={isDialogOpen} 
        onClose={() => setIsDialogOpen(false)} 
        onSave={addEquipo} 
      />
    </div>
  )
}

