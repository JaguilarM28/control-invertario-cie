"use client"

import { useState, useMemo, useEffect } from "react"
import { Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { EmpleadoTable } from "@/components/empleado-table"
import { EmpleadoDialog } from "@/components/empleado-dialog"
import { SearchInput } from "@/components/search-input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

export default function EmpleadosPage() {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [empleados, setEmpleados] = useState([
    {
      id: 1,
      numeroEmpleado: "EMP001",
      nombres: "Juan",
      apellidos: "Pérez",
      nombreCargo: "Desarrollador",
      empresa: "TechCorp",
      departamento: "IT",
      nomJefe: "María González",
      puestoJefe: "Gerente IT",
      estado: "Activo",
    },
    // Añade más empleados de ejemplo aquí
  ])

  useEffect(() => {
    fetch("/api/empleados")
      .then((response) => response.json())
      .then((data) => setEmpleados(data))
      .catch((error) => console.error("Error:", error))
  }, [])

  const filteredEmpleados = useMemo(() => {
    return empleados.filter((empleado) =>
      Object.values(empleado).some((value) => value.toString().toLowerCase().includes(searchTerm.toLowerCase())),
    )
  }, [empleados, searchTerm])

  const addEmpleado = async (empleado) => {
    try {
      const response = await fetch("/api/empleados", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(empleado),
      })
      if (!response.ok) throw new Error("Network response was not ok")
      const newEmpleado = await response.json()
      setEmpleados([...empleados, newEmpleado])
    } catch (error) {
      console.error("Error:", error)
    }
  }

  const updateEmpleado = (updatedEmpleado) => {
    setEmpleados(empleados.map((emp) => (emp.id === updatedEmpleado.id ? updatedEmpleado : emp)))
  }

  const deleteEmpleado = (id) => {
    setEmpleados(empleados.filter((emp) => emp.id !== id))
  }

  const departmentData = useMemo(() => {
    const departments = {}
    empleados.forEach((empleado) => {
      if (departments[empleado.departamento]) {
        departments[empleado.departamento]++
      } else {
        departments[empleado.departamento] = 1
      }
    })
    return Object.entries(departments).map(([name, value]) => ({ name, value }))
  }, [empleados])

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold">Empleados</h1>
        <div className="flex items-center gap-4">
          <SearchInput placeholder="Buscar empleados..." value={searchTerm} onChange={setSearchTerm} />
          <Button onClick={() => setIsDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" /> Agregar Empleado
          </Button>
        </div>
      </div>
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Empleados por Departamento</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={departmentData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="value" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Lista de Empleados</CardTitle>
          </CardHeader>
          <CardContent>
            <EmpleadoTable empleados={filteredEmpleados} onEdit={updateEmpleado} onDelete={deleteEmpleado} />
          </CardContent>
        </Card>
      </div>
      <EmpleadoDialog isOpen={isDialogOpen} onClose={() => setIsDialogOpen(false)} onSave={addEmpleado} />
    </div>
  )
}

