"use client"

import { useState } from "react"
import { Plus } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { AsignacionTable } from "@/components/asignacion-table"
import { AsignacionDialog } from "@/components/asignacion-dialog"

export default function AsignacionesPage() {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [asignaciones, setAsignaciones] = useState([
    { id: 1, empleado: "Juan Pérez", equipo: "Laptop Dell XPS", fechaAsignacion: "2023-06-01", fechaDevolucion: null },
    { id: 2, empleado: "María García", equipo: "Monitor LG", fechaAsignacion: "2023-05-15", fechaDevolucion: null },
    { id: 3, empleado: "Carlos Rodríguez", equipo: "Teclado Logitech", fechaAsignacion: "2023-04-20", fechaDevolucion: "2023-06-10" },
  ])

  const addAsignacion = (asignacion) => {
    setAsignaciones([...asignaciones, { ...asignacion, id: asignaciones.length + 1 }])
  }

  const updateAsignacion = (updatedAsignacion) => {
    setAsignaciones(asignaciones.map(asig => asig.id === updatedAsignacion.id ? updatedAsignacion : asig))
  }

  const deleteAsignacion = (id) => {
    setAsignaciones(asignaciones.filter(asig => asig.id !== id))
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Asignaciones</h1>
        <Button onClick={() => setIsDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" /> Nueva Asignación
        </Button>
      </div>
      <AsignacionTable 
        asignaciones={asignaciones} 
        onEdit={updateAsignacion} 
        onDelete={deleteAsignacion} 
      />
      <AsignacionDialog 
        isOpen={isDialogOpen} 
        onClose={() => setIsDialogOpen(false)} 
        onSave={addAsignacion} 
      />
    </div>
  )
}

